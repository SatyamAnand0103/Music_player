// import React from "react";
// function Audio() {
//   return (
//     <>
//       <audio className="myAudios" src={require("./audios/Tera Hi.mp3")}></audio>
//       <audio className="myAudios" src={require("./audios/Hmk.mp3")}></audio>
//       <audio
//         className="myAudios"
//         src={require("./audios/Jab Bhi Teri.mp3")}
//       ></audio>
//       <audio
//         className="myAudios"
//         src={require("./audios/Mohabbat.mp3")}
//       ></audio>
//       <audio className="myAudios" src={require("./audios/Kham.mp3")}></audio>
//       <audio className="myAudios" src={require("./audios/Hum.mp3")}></audio>
//       <audio className="myAudios" src={require("./audios/Naina.mp3")}></audio>

//       <audio
//         className="myAudios"
//         src={require("./audios/MainDhoondne.mp3")}
//       ></audio>

//       <audio className="myAudios" src={require("./audios/Pal Pal.mp3")}></audio>

//       <audio
//         className="myAudios"
//         src={require("./audios/Milne hai.mp3")}
//       ></audio>

//       <audio className="myAudios" src={require("./audios/Shiddat.mp3")}></audio>

//       <audio className="myAudios" src={require("./audios/SariDunia.mp3")}></audio>

//       <audio className="myAudios" src={require("./audios/HareKrishna.mp3")}></audio>

//       <audio className="myAudios" src={require("./audios/OMahi.mp3")}></audio>

//       <audio className="myAudios" src={require("./audios/SunaSuna.mp3")}></audio>

//       <audio className="myAudios" src={require("./audios/SaansonKo.mp3")}></audio>

//       <audio className="myAudios" src={require("./audios/Bhagwankahan.mp3")}></audio>

//       <audio className="myAudios" src={require("./audios/Husn.mp3")}></audio>

//       <audio className="myAudios" src={require("./audios/KalHoNaHo.mp3")}></audio>

//       <audio className="myAudios" src={require("./audios/Tune.mp3")}></audio>



//     </>
//   );
// }

// export default Audio;
